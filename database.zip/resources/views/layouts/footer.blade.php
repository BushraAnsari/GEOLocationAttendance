<footer class="footer">
<!-- Log on to bntech.com for more projects! -->
     ©  {{date('Y')}}  Dayfresh CC Program-KLI - Crafted with <i class="mdi mdi-heart text-danger"></i> by BN Tech</span>.
</footer>